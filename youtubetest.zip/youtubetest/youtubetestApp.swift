//
//  youtubetestApp.swift
//  youtubetest
//
//  Created by holly on 1/11/23.
//

import SwiftUI

@main
struct youtubetestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
